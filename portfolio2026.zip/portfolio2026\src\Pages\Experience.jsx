import React from "react";
import { FaBriefcase, FaMapMarkerAlt, FaCalendarAlt, FaPhoneAlt, FaCheckCircle } from "react-icons/fa";
import { internshipDetails } from "../Data/experience";

function splitPoint(item) {
  const idx = item.indexOf(":");
  if (idx === -1) return { title: null, text: item };
  return { title: item.slice(0, idx), text: item.slice(idx + 1).trim() };
}

function Experience() {
  const exp = internshipDetails;

  return (
    <section className="text-white py-10 px-4 sm:px-6 max-w-5xl mx-auto">
      <h1 className="text-3xl font-bold text-center mb-10">Experience</h1>

      {/* Role card */}
      <div className="bg-gray-900 rounded-xl p-6 border border-gray-800 shadow-xl">
        <div className="flex items-start gap-4">
          <div className="text-3xl text-yellow-400 mt-1 shrink-0">
            <FaBriefcase />
          </div>
          <div className="flex-1">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
              <h2 className="text-2xl font-bold text-yellow-400">{exp.role}</h2>
              <span className="inline-flex items-center gap-2 text-xs font-medium bg-green-900/40 text-green-400 border border-green-800 px-3 py-1 rounded-full w-fit">
                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                Currently working
              </span>
            </div>
            <p className="text-lg text-gray-200 mt-1">
              <strong>{exp.company}</strong>
              <span className="text-gray-500"> · {exp.classification}</span>
            </p>
            <div className="flex flex-wrap gap-x-5 gap-y-1 text-sm text-gray-400 mt-2">
              <span className="inline-flex items-center gap-2">
                <FaCalendarAlt /> {exp.startDate} – {exp.endDate}
              </span>
              <span className="inline-flex items-center gap-2">
                <FaMapMarkerAlt /> {exp.location}
              </span>
            </div>
            <p className="text-gray-300 mt-4 leading-relaxed">{exp.summary}</p>
          </div>
        </div>

        <h3 className="text-lg font-semibold text-yellow-400 mt-8 mb-4">Key Responsibilities</h3>
        <div className="grid md:grid-cols-2 gap-4">
          {exp.responsibilities.map((item) => {
            const { title, text } = splitPoint(item);
            return (
              <div
                key={item}
                className="bg-gray-800/60 border border-gray-700 rounded-lg p-4 hover:border-yellow-500/50 transition-colors"
              >
                {title && <p className="font-semibold text-gray-100 mb-1">{title}</p>}
                <p className="text-sm text-gray-400 leading-relaxed">{text}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Featured work */}
      {exp.highlights.map((work) => (
        <div
          key={work.name}
          className="mt-10 bg-gray-900 rounded-xl p-6 border border-blue-900/60 shadow-xl"
        >
          <span className="text-xs uppercase tracking-wider text-blue-400 font-semibold">
            Featured work at {exp.company}
          </span>
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 mt-2">
            <h3 className="text-2xl font-bold text-blue-400 inline-flex items-center gap-3">
              <FaPhoneAlt className="text-xl" /> {work.name}
            </h3>
            <span className="text-sm text-gray-500 font-medium">{work.date}</span>
          </div>
          <p className="text-gray-400 italic mt-1">{work.tagline}</p>
          <p className="text-gray-300 mt-4 leading-relaxed">{work.description}</p>

          {work.image && (
            <a href={work.image} target="_blank" rel="noopener noreferrer" className="block mt-6">
              <img
                src={work.image}
                alt={`${work.name} architecture diagram`}
                loading="lazy"
                className="w-full max-h-96 object-contain bg-white rounded-lg border border-gray-700 hover:border-blue-500 transition-colors"
              />
            </a>
          )}

          <h4 className="text-sm font-semibold text-gray-400 mt-6 mb-3">What I did</h4>
          <ul className="space-y-3">
            {work.contributions.map((c) => (
              <li key={c} className="flex gap-3 text-gray-300 leading-relaxed">
                <FaCheckCircle className="text-blue-400 mt-1 shrink-0" />
                <span>{c}</span>
              </li>
            ))}
          </ul>

          <div className="mt-6 pt-4 border-t border-gray-800">
            <span className="text-sm font-semibold text-gray-400 block mb-2">Tech & Concepts:</span>
            <div className="flex flex-wrap gap-2">
              {work.techStack.map((tech) => (
                <span
                  key={tech}
                  className="bg-gray-800 text-gray-300 text-xs px-3 py-1 rounded-full border border-gray-700"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>
        </div>
      ))}
    </section>
  );
}

export default Experience;
